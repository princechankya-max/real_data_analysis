@echo off
cd /d c:\Users\Priyanshu\OneDrive\ecommerce
python data_analysis.py > analysis_output.txt 2>&1
echo Analysis complete! Check analysis_output.txt
pause
